class ServicePackage {
  private String service;
  private int  value;
        /*
     * Code ini merupaka codekelas yang memiliki hubungan regeresiasi dengan kelas pengiriman,servicepackge,status
     * 
     * Kode ini bisa bekerja sendiri tampa kelas lain 
     * code ini bisa diturunakan atau bisa menjadi super class atau Subclass
     * 
     * 
     * 
     */

          public void servicePackage(String service, int value) {
            this.service = service;
            this.value = value;
          }
          public String getService() {
            return service;
          }
          public void setService(String service) {
            this.service = service;
          }
          public int getValue() {
            return value;
          }
          public void setValue(int value) {
            this.value = value;
          }
}
